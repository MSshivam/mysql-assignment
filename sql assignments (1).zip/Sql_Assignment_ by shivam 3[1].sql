use assignments;
DELIMITER //
Create Procedure order_status(in year int, in month int)
Begin
     select ordernumber , orderdate, status from orders where date_format(orderdate, "%m-%y") in ( year, month) ;
END //
DELIMITER ;
call order_status(2003,1);

create table cancellations ( id integer primary key auto_increment, customernumber integer, ordernumber integer,
							   Foreign key (customernumber) References customers(customernumber), Foreign key (ordernumber) References orders(ordernumber));
Alter table cancellations add column comments char(50);
desc cancellations;


select * from orders;
select customernumber, ordernumber, status from orders where status='cancelled';
select * from cancellations;
DELIMITER //
                       CREATE DEFINER=`root`@`localhost` FUNCTION `purchase_status`(custnum int) RETURNS varchar(20) CHARSET utf8mb4
							DETERMINISTIC
							BEGIN
								Declare amt int default 0;
								Declare purchase_status varchar(20);
								
							  Select sum(amount) into amt from payments where customernumber=custnum;
							   
								  If amt < 25000 then 
									   set purchase_status='Silver';
								   elseif amt between 25000 and 50000 then
										 set purchase_status='Gold';
									else
										 set purchase_status='Platinum';
								  End If;

							RETURN purchase_status;
							END
            //

 select assignments.purchase_status(112);
 select assignments.purchase_status(103);
 select assignments.purchase_status(114);
 select customernumber, customername, purchase_status(customernumber) from customers;
 DELIMITER //
CREATE TRIGGER delete_cascade
	AFTER DELETE on movies
		FOR EACH ROW 
		BEGIN
			UPDATE rentals
				SET movieid = NULL
					WHERE movieid
                       NOT IN
				    ( SELECT distinct id
					    from movies );
		END //
DELIMITER ;

drop trigger if exists delete_cascade;
select * from movies;
         insert into movies(id,                 title,    category)
                     values(11, "Cronicals of Narnia", "Adventure");
select * from rentals;
         insert into rentals(memid, first_name, last_name, movieid)
                      values(    9,     "Moin",   "Dalvi",      11);

delete from movies where id = 11;
select id from movies;
select * from rentals;
DELIMITER //
        Create Trigger update_cascade
		   After update on movies
			 For each row
			 BEGIN
			    Update rentals
				    SET movieid = new.id
						WHERE movieid = old.id  ;
			 END //
DELIMITER ;

DROP TRIGGER If Exists update_cascade;
     insert into movies(id,                 title,    category)
                 values(12, "Cronicals of Narnia", "Adventure");
update rentals 
	set movieid = 12
    where memid = 9;
    
update movies
    set id = 11
    where title regexp 'Cronicals';

select * from movies;
select * from rentals;

select * 
from employee
       order by salary desc
             limit 2,1;
select *,
       dense_rank() over (order by salary desc) as rank_salary
       from employee;

     
     